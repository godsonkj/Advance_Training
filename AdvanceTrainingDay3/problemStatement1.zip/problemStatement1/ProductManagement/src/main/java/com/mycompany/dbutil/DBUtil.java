package com.mycompany.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBUtil {
	
	public static final String URL = "jdbc:mysql://localhost:3306/productdb";
	
	public static final String USERNAME = "root";
	
	public static final String USERPASS = "";
	
	public PreparedStatement pstmt;
	
	public ResultSet theResultSet,secondResultSet;
	
	public Connection dbCon;
	
	public DBUtil(){
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			dbCon = DriverManager.getConnection(URL, USERNAME, USERPASS);
		
			
		} catch (ClassNotFoundException e) {
			System.out.println("Can't load the driver : " + e.getMessage());
		} catch (SQLException e) {
			System.out.println("Issues while connecting to db : " + e.getMessage());
		}
		
	}

}
