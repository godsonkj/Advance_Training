package com.mycompany.dao;

import java.sql.SQLException;
import java.util.Scanner;

import com.mycompany.dbutil.DBUtil;
import com.mycompany.domain.Product;

public class ProductManagementDAO {
	
	
	public void optionSelect() throws SQLException {
		DBUtil dbconfig= new DBUtil();
		Product pro = new Product();
		System.out.println("\nA. View Products\nB. Add Products\nC. Update Product\nD. Delete Product\n"
				+ "E. Search Product\nF. Exit");
		System.out.println("\n====================================");
		System.out.println("\n Enter Your Choice");
		System.out.println("\n====================================");
	
		Scanner scan = new Scanner(System.in);
		String choice=scan.nextLine();
		System.out.println("\n------------------------------------\n");
		int price;
		String id,name,qry;
		switch(choice) {
		case "A","a":System.out.println("View Products\n");
					 qry="select * from product";
					 dbconfig.pstmt = dbconfig.dbCon.prepareStatement(qry);
					 dbconfig.theResultSet=dbconfig.pstmt.executeQuery();
					 while (dbconfig.theResultSet.next()) {
						 System.out.println("Product ID: "+dbconfig.theResultSet.getString("Id"));
						 System.out.println("Product Name:"+dbconfig.theResultSet.getString("Name"));
						 System.out.println("Product Price: "+dbconfig.theResultSet.getInt("Price"));
						 System.out.println();
					 }
					 
					 optionSelect();
					 break;
					 
					 
		case "B","b":System.out.println("Add Products\n");
					 System.out.println("\n------------------------------------\n");
					 System.out.println("Enter Product ID:");
					 System.out.println("\n------------------------------------\n");
					 pro.setId(scan.nextLine());
					 System.out.println("\n------------------------------------\n");
					 System.out.println("Enter Product Name :");
					 System.out.println("\n------------------------------------\n");
					 pro.setName(scan.nextLine());
					 System.out.println("\n------------------------------------\n");
					 System.out.println("Enter the Product Price :");
					 System.out.println("\n------------------------------------\n");
					 pro.setPrice(scan.nextInt()); 
					 scan.nextLine();
					 qry="insert into product values(?,?,?)";
					 dbconfig.pstmt = dbconfig.dbCon.prepareStatement(qry);
					 dbconfig.pstmt.setString(1, pro.getId());
					 dbconfig.pstmt.setString(2, pro.getName());
					 dbconfig.pstmt.setInt(3, pro.getPrice());
					 if(dbconfig.pstmt.executeUpdate()>0)
						 System.out.println("Product Added successfully");
					 
					 optionSelect();
					 break;
		case "c","C":System.out.println("Update Product\n");
					 System.out.println("\n------------------------------------\n");
		             System.out.println("Enter Product ID:");
		             System.out.println("\n------------------------------------\n");
		             pro.setId(scan.nextLine());
		             System.out.println("\n------------------------------------\n");
					 System.out.println("Enter New Product Name :");
					 System.out.println("\n------------------------------------\n");
					 pro.setName(scan.nextLine());
					 System.out.println("\n------------------------------------\n");
					 System.out.println("Enter New Product Price :");
					 System.out.println("\n------------------------------------\n");
					 pro.setPrice(scan.nextInt()); 
					 scan.nextLine();
					 qry="update product set Name=? , Price=? where Id=?";
					 dbconfig.pstmt = dbconfig.dbCon.prepareStatement(qry);
					 dbconfig.pstmt.setString(3, pro.getId());
					 dbconfig.pstmt.setString(1, pro.getName());
					 dbconfig.pstmt.setInt(2, pro.getPrice());
					 if(dbconfig.pstmt.executeUpdate()>0)
						 System.out.println("Product Updated successfully");
					 else
						 System.out.println("The Product With the Id Doesnot Exist");
					 optionSelect();
					 break;
					 
					 
		case "d","D":System.out.println("Delete Product\n");
					 System.out.println("\n------------------------------------\n");
					 System.out.println("Enter Product ID:");
					 System.out.println("\n------------------------------------\n");
					 pro.setId(scan.nextLine());
					 qry="delete from product where Id = ?";
					 dbconfig.pstmt = dbconfig.dbCon.prepareStatement(qry);
					 dbconfig.pstmt.setString(1, pro.getId());
					 if(dbconfig.pstmt.executeUpdate()>0)
						 System.out.println("Product Deletion successfully");
					 else
						 System.out.println("The Product With the Id Doesnot Exist");
					 optionSelect();
					 break;
					 
		case "E","e":System.out.println("Search Product\n");
		       		 System.out.println("\n------------------------------------\n");
		       		 System.out.println("Enter Product ID:");
		       		 System.out.println("\n------------------------------------\n");
		       		 pro.setId(scan.nextLine());
		       		 qry="select * from product where Id = ?";
					 dbconfig.pstmt = dbconfig.dbCon.prepareStatement(qry);
					 dbconfig.pstmt.setString(1, pro.getId());
					 dbconfig.theResultSet=dbconfig.pstmt.executeQuery();
					 while (dbconfig.theResultSet.next()) {
						 System.out.println("Product ID: "+dbconfig.theResultSet.getString("Id"));
						 System.out.println("Product Name:"+dbconfig.theResultSet.getString("Name"));
						 System.out.println("Product Price: "+dbconfig.theResultSet.getInt("Price"));
						 System.out.println();
					 }
					 
					 optionSelect();
					 break;
		case "f","F":System.out.println("**************THANK YOU**************");
					 break;
		       		 
					 
		}
	}

}
