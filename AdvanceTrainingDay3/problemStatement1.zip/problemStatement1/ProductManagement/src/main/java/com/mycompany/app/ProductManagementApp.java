package com.mycompany.app;

import java.sql.SQLException;

import com.mycompany.dao.ProductManagementDAO;

public class ProductManagementApp {
	public static void main(String[] args) throws SQLException {
		
		ProductManagementDAO pro = new ProductManagementDAO();
		pro.optionSelect();
	}

}
