package problemStatements11;


import java.util.Scanner;

public class coinChange {
public static void main(String[] args) {
	int amount;
	System.out.println("Enter the change of amount needed:");
	amount=new Scanner((System.in)).nextInt();
	System.out.println(change(0,amount));
	
	
}


public static int change(int no,int amount) {
	int[] note= {1,2,5,10,20,50,100,500,2000};

	for (int i=8;i>=0;i--) {
		if(amount==0)
			break;
		//System.out.println("i= "+note[i]);
		if( amount-note[i]>=0) {
			//System.out.println("Amt= "+amount);
			no+=1;
			amount=amount-note[i];
			return change(no,amount);
			
		}
		
	}
	
		return no;
	

	
	
	
}
}
