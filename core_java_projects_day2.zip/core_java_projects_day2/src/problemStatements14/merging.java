package problemStatements14;

import java.util.Arrays;

public class merging {
	public static void main(String[] args) {
		int[]arr1={1,2,3};
		int[]arr2 ={5,6,4};
		int[] finalArray=sort(arr1,arr2);
		int finalLength= finalArray.length;
		System.out.println("The Sorted order is ");
		for(int i=0;i<finalLength;i++)
		System.out.print(finalArray[i]+" ");
		
		
	}
	
	public static int[] sort(int[]first, int[]second) {
		int len1=first.length, len2=second.length, finalLength= len1+len2;
		int[] finalArray=new int[finalLength];
		for(int i=0;i<len1;i++) {
			finalArray[i]=first[i];
		}
		for(int i=0,j=len1;j<finalLength;i++,j++) {
			finalArray[j]=second[i];
		}

		
		Arrays.sort(finalArray);
		
		return finalArray;
		
		
		
	}

}

