package com.problemStatements3;

public class Ointment implements MedicineInfo {

	@Override
	public void displayLabel() {
		System.out.println("For External Use Only");

	}

}

