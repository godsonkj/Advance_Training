package com.problemStatements3;

import java.util.Random;

public class MainProgram {
	public static void main(String[] args) {
	MedicineInfo[] medicines = new MedicineInfo[10];


	 Random rand = new Random();
	 
	    for (int i = 0; i < 10; i++) {
	    	int randomNum = rand.nextInt(3) + 1;
	    	
	    	if (randomNum == 1)
	    		medicines[i] = new Tablet();
	    	else if (randomNum == 2)
	    		medicines[i] = new Syrup();
	    	else if (randomNum == 3)
	    		medicines[i] = new Ointment();
	    	
	    	medicines[i].displayLabel();
	    }
	    System.out.println();
	    System.out.println();
	    
	    for (int i = 0; i < 10; i++) {
	    	if (medicines[i] instanceof Tablet) 
	    		System.out.println("Tablet is stored at index " + i);
	    	else if (medicines[i] instanceof Syrup) 
	    		System.out.println("Syrup is stored at index " + i);
	    	else if (medicines[i] instanceof Ointment) 
	    		System.out.println("Ointment is stored at index " + i);
	    }
}
}
