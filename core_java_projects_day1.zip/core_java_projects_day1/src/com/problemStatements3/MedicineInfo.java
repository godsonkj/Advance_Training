package com.problemStatements3;

public interface MedicineInfo {
	public void displayLabel();

}
