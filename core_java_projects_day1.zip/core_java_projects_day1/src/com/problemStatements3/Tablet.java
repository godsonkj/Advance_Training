package com.problemStatements3;

public class Tablet implements MedicineInfo {

	@Override
	public void displayLabel() {
		System.out.println("Store in cold dry places only");

	}

}
