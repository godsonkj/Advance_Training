package com.problemStatements1;

import java.util.Scanner;

public class rectangle {
	int length;
	int breadth;
	int area;
	
	public rectangle() {
		length=0;
		breadth=0;
		
	}
	public rectangle(int length, int breadth) {
		this.length=length;
		this.breadth=breadth;
	}
	void input() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter length of rectangle: ");
        length = in.nextInt();
        System.out.print("Enter breadth of rectangle: ");
        breadth = in.nextInt();
    }
	void calculate() {
        area = length * breadth;
        
    }

    void display() {
        System.out.println("Area of Rectangle = " + area);
       
    }
    
    public static void main(String[] args) {
		rectangle rect1 = new rectangle(10, 16);
		rect1.calculate();
		rect1.display();
		System.out.println();
		rectangle rect2 = new rectangle();
		rect2.input();
		rect2.calculate();
		rect2.display();
	}



}
