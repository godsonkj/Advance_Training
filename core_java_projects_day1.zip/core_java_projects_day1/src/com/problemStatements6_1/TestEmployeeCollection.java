package com.problemStatements6_1;

import java.util.Vector;

public class TestEmployeeCollection {
	public static void main(String[] args) {
		Vector<Employee> v = addInput();
		display(v);
		}



	public static Vector<Employee> addInput() {
		Employee e1=new Employee (111,"godson", "hyderabad");
		Employee e2=new Employee (222,"shiva", "shadnagar");
		Employee e3=new Employee (333,"charan", "anantapur");
		Vector<Employee> v=new Vector<Employee>();
		v.add(e1);
		v.add(e2);
		v.add(e3);
		return v;
	
	}
	public static void display(Vector<Employee> v) {
		for(Employee e:v)
		{
			System.out.println(e.getEmpid()+"\t"+e.getEname()+"\t"+e.getAddress());
		}
	}


}
