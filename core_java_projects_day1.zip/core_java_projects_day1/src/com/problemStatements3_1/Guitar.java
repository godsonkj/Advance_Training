package com.problemStatements3_1;

public class Guitar extends instrument {
	@Override
	public void play() {
		System.out.println("Guitar is playing  tin  tin  tin for Guitar class");

	}


}

