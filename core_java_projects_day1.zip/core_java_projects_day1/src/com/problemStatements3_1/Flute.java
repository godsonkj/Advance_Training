package com.problemStatements3_1;

public class Flute extends instrument{

	@Override
	public void play() {
		System.out.println("Flute is playing  toot toot toot toot for Flute class");

	}
}
