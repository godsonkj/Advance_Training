package com.problemStatements3_1;

public abstract class instrument {
	public abstract void play();

}

